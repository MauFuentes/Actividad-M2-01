//
//  DetalleVC.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 12/05/23.
//

import UIKit

class DetalleVC: UIViewController {

    var pelicula: Movie?
    
    
    @IBOutlet weak var descripcion: UILabel!
    @IBOutlet weak var imagenPelicula: UIImageView!
    
    
    @IBOutlet weak var titulo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        imagenPelicula.image = pelicula?.image
        titulo.text = pelicula?.titulo
       
        descripcion.text = pelicula?.desc
        
    }
    

    

}
