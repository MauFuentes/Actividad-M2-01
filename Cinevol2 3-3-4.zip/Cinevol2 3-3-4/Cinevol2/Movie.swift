//
//  Movie.swift
//  Cinevol2
//
//  Created by Facultad de Contaduría y Administración on 09/05/23.
//

import Foundation
import UIKit

struct Movie {
    
    let titulo: String
    let desc: String
    let image: UIImage
    
}

let movies: [Movie] = [
    Movie(titulo: "Pretty Woman", desc: "Un empresario contrata a una prostituta hermosa para que sea su acompañante durante una semana de negocios en Beverly Hills.", image: UIImage(named: "PrettyWomanPortada")!),
    Movie(titulo: "Django", desc: "Un exesclavo une fuerzas con un cazador de recompensas alemán que lo liberó y lo ayuda a buscar a los criminales más buscados del sur de los Estados Unidos, con la esperanza de reencontrarse con su esposa.", image: UIImage(named: "DjangoPortada")!),
    Movie(titulo: "Star Wars", desc: "Seducido por el lado oscuro, Anakin Skywalker se rebela contra su mentor, Obi-Wan Kenobi, y se convierte en Darth Vader ",image: UIImage(named: "StarWarsPortada")!),
    Movie(titulo: "ScarFace ", desc: "Un inmigrante cubano de las cárceles de Fidel Castro provoca un camino de destrucción en su ascenso en el mundo de las drogas de Miami.",image: UIImage(named: "ScarfacePortada")!),
    Movie(titulo: "El Joven Mano de Tijera", desc: "La creación incompleta de un inventor fallecido se convierte instantáneamente en una celebridad cuando una mujer alegre lo lleva a su casa.",image: UIImage(named: "JovenPortada")!),
    Movie(titulo: "Blood in Blood out", desc: "La vida de una pandilla urbana repercute en dos hermanos y un primo que van a parar en lados opuestos de la ley.",image: UIImage(named: "SangreXSangrePortada")!)
]
