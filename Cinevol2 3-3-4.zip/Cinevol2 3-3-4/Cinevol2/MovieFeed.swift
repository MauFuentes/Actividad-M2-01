//
//  MovieFeed.swift
//  Cinevol2
//
//  Created by Facultad Contaduría y Administración on 16/05/23.
//

import Foundation
import UIKit

struct MovieFeed {
    let image: UIImage
}

let moviesFeed: [MovieFeed] = [
    MovieFeed(image: UIImage(named: "PrettyWoman")!),
    MovieFeed(image: UIImage(named: "Django")!),
    MovieFeed(image: UIImage(named: "StarWars")!),
    MovieFeed(image: UIImage(named: "ScarFace")!),
    MovieFeed(image: UIImage(named: "Joven")!),
    MovieFeed(image: UIImage(named: "SangreXSangre")!),
]
